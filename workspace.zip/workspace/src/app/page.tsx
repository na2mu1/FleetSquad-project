import Navbar from "@/components/sections/Navbar";
import Hero from "@/components/sections/Hero";
import Services from "@/components/sections/Services";
import FleetTypes from "@/components/sections/FleetTypes";
import WhyFleetSquad from "@/components/sections/WhyFleetSquad";
import Dashboard from "@/components/sections/Dashboard";
import Coverage from "@/components/sections/Coverage";
import Process from "@/components/sections/Process";
import Testimonials from "@/components/sections/Testimonials";
import Faq from "@/components/sections/Faq";
import CtaSection from "@/components/sections/CtaSection";
import Footer from "@/components/sections/Footer";
import ScrollProgress from "@/components/site/ScrollProgress";

export default function Home() {
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-fleet-navy focus:px-4 focus:py-2 focus:text-white"
      >
        Skip to content
      </a>
      <ScrollProgress />
      <Navbar />
      <main id="main" className="flex-1">
        <Hero />
        <Services />
        <FleetTypes />
        <WhyFleetSquad />
        <Dashboard />
        <Coverage />
        <Process />
        <Testimonials />
        <Faq />
        <CtaSection />
      </main>
      <Footer />
    </>
  );
}
