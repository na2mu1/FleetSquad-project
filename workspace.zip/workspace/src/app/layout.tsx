import type { Metadata } from "next";
import { Geist_Mono, Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://fleetsquad.io"),
  title: {
    default: "FleetSquad — Nationwide On-Site Fleet Maintenance",
    template: "%s | FleetSquad",
  },
  description:
    "FleetSquad sends ASE Master Technicians to your location for preventive maintenance, mobile diagnostics, repairs, DOT inspections, and emergency roadside service across the nation.",
  keywords: [
    "fleet maintenance",
    "mobile fleet service",
    "ASE master technicians",
    "commercial vehicle repair",
    "DOT inspections",
    "emergency roadside service",
    "preventive maintenance",
    "fleet management",
  ],
  openGraph: {
    title: "FleetSquad — Keep Every Fleet Mission Ready",
    description:
      "ASE Master Technicians come to your location for preventive maintenance, diagnostics, repairs, inspections, and emergency roadside service nationwide.",
    url: "https://fleetsquad.io",
    siteName: "FleetSquad",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FleetSquad — Keep Every Fleet Mission Ready",
    description:
      "ASE Master Technicians come to your location for preventive maintenance, diagnostics, repairs, and emergency roadside service nationwide.",
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: "/favicon.svg",
  },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "FleetSquad",
  description:
    "Nationwide on-site commercial fleet maintenance by ASE Master Technicians.",
  url: "https://fleetsquad.io",
  areaServed: "US",
  serviceType: [
    "Preventive Maintenance",
    "Fleet Repairs",
    "Mobile Diagnostics",
    "Emergency Roadside",
    "Scheduled Maintenance",
    "DOT Inspections",
  ],
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${jakarta.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {children}
      </body>
    </html>
  );
}
