import { Wheel, wheelDefs } from "./Wheels";

export default function Pickup() {
  return (
    <svg viewBox="0 0 280 112" role="img" aria-label="Pickup truck">
      <defs>
        <linearGradient id="pk-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2c5090" />
          <stop offset="55%" stopColor="#183563" />
          <stop offset="100%" stopColor="#0d2347" />
        </linearGradient>
        <linearGradient id="pk-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7fb2e8" />
          <stop offset="100%" stopColor="#163a6e" />
        </linearGradient>
        {wheelDefs("pk-wheel-shade")}
      </defs>

      <path
        d="M16 44 C14 40 15 36 19 35 L44 32 C52 26 62 22 74 22 L98 22 C102 22 104 25 104 30 L104 44 Z"
        fill="url(#pk-body)"
      />

      <rect x="112" y="36" width="158" height="40" rx="4" fill="url(#pk-body)" />

      <path
        d="M104 34 L106 34 C112 34 114 38 114 42 L114 76 L104 76 Z"
        fill="url(#pk-body)"
      />

      <path
        d="M60 34 L90 26 C98 24 102 28 102 34 L102 44 L60 44 Z"
        fill="url(#pk-glass)"
      />

      <path d="M116 40 L266 40 L266 44 L116 44 Z" fill="#56a8ff" opacity={0.35} />

      <path
        d="M18 50 C20 46 26 44 32 43 L100 41 L100 76 L16 76 C11 76 10 72 12 66 Z"
        fill="url(#pk-body)"
      />

      <path d="M26 46 L36 46 L36 74 L26 74 Z" fill="#12305c" />

      <line x1="120" y1="44" x2="120" y2="72" stroke="#0d2347" strokeWidth="2" />
      <line x1="150" y1="44" x2="150" y2="72" stroke="#0d2347" strokeWidth="2" />
      <line x1="180" y1="44" x2="180" y2="72" stroke="#0d2347" strokeWidth="2" />
      <line x1="210" y1="44" x2="210" y2="72" stroke="#0d2347" strokeWidth="2" />
      <line x1="240" y1="44" x2="240" y2="72" stroke="#0d2347" strokeWidth="2" />

      <path d="M268 40 L272 40 C274 44 273 47 269 48 L265 48 Z" fill="#fff" opacity={0.9} />
      <path d="M268 40 L272 40 C274 44 273 47 269 48 L265 48 Z" fill="#ffd98a" opacity={0.7} />

      <rect x="120" y="30" width="150" height="2.5" rx="1.25" fill="#2c5090" />

      <path
        d="M66 34 C72 38 76 42 78 46 L78 54 C72 54 68 54 66 54 Z"
        fill="#56a8ff"
        opacity={0.5}
      />

      <rect x="80" y="52" width="16" height="4" rx="2" fill="#0d2347" />

      <path d="M10 72 L20 72 M12 68 L22 68" stroke="#0a1d3d" strokeWidth="2.4" strokeLinecap="round" />

      <rect x="2" y="86" width="276" height="3" rx="1.5" fill="#0a1d3d" opacity="0.85" />

      <Wheel cx={56} cy={88} r={13.5} shadeId="pk-wheel-shade" />
      <Wheel cx={226} cy={88} r={13.5} shadeId="pk-wheel-shade" />
    </svg>
  );
}
