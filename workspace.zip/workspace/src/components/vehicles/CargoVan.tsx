import { Wheel, wheelDefs } from "./Wheels";

export default function CargoVan() {
  return (
    <svg viewBox="0 0 280 122" role="img" aria-label="Cargo van">
      <defs>
        <linearGradient id="cv-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2c5090" />
          <stop offset="55%" stopColor="#183563" />
          <stop offset="100%" stopColor="#0d2347" />
        </linearGradient>
        <linearGradient id="cv-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#8cc0f2" />
          <stop offset="100%" stopColor="#1a3f78" />
        </linearGradient>
        {wheelDefs("cv-wheel-shade")}
      </defs>

      <path
        d="M16 30 L214 30 C226 30 232 32 238 38 L252 48 C259 53 263 58 264 65 L265 78 C265 82 261 84 256 84 L20 84 C12 84 8 80 8 73 L10 38 C10 33 12 30 16 30 Z"
        fill="url(#cv-body)"
      />

      <path
        d="M214 30 C226 30 232 32 238 38 L250 47 C255 50 259 54 262 58 L214 58 Z"
        fill="url(#cv-glass)"
      />

      <path d="M12 74 L266 74 L266 78 L12 78 Z" fill="#56a8ff" opacity={0.3} />

      <line x1="204" y1="34" x2="204" y2="80" stroke="#0d2347" strokeWidth="2" />
      <line x1="150" y1="34" x2="150" y2="80" stroke="#0d2347" strokeWidth="2" />
      <line x1="96" y1="34" x2="96" y2="80" stroke="#0d2347" strokeWidth="2" />

      <rect x="210" y="60" width="16" height="4.5" rx="2" fill="#0d2347" />

      <rect x="212" y="48" width="30" height="22" rx="3" fill="#0d2347" opacity="0.55" />

      <path
        d="M22 30 C28 30 32 32 32 36 L32 48 L8 48 L8 36 C8 33 13 30 22 30 Z"
        fill="url(#cv-glass)"
      />

      <path d="M260 62 L265 62 C268 65 267 68 262 69 L258 69 Z" fill="#fff" opacity={0.9} />
      <path d="M260 62 L265 62 C268 65 267 68 262 69 L258 69 Z" fill="#ffd98a" opacity={0.7} />

      <path d="M8 70 L18 70 M10 66 L20 66" stroke="#0a1d3d" strokeWidth="2.4" strokeLinecap="round" />

      <rect x="2" y="92" width="276" height="3" rx="1.5" fill="#0a1d3d" opacity="0.85" />

      <Wheel cx={70} cy={94} r={13.5} shadeId="cv-wheel-shade" />
      <Wheel cx={216} cy={94} r={13.5} shadeId="cv-wheel-shade" />
    </svg>
  );
}
