import { Wheel, wheelDefs } from "./Wheels";

export default function UtilityTruck() {
  return (
    <svg viewBox="0 0 320 132" role="img" aria-label="Utility fleet vehicle">
      <defs>
        <linearGradient id="ut-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2f5496" />
          <stop offset="55%" stopColor="#193762" />
          <stop offset="100%" stopColor="#0e2449" />
        </linearGradient>
        <linearGradient id="ut-tool" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f2f7fe" />
          <stop offset="100%" stopColor="#d5e3f6" />
        </linearGradient>
        <linearGradient id="ut-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#8cc0f2" />
          <stop offset="100%" stopColor="#1a3f78" />
        </linearGradient>
        {wheelDefs("ut-wheel-shade")}
      </defs>

      <rect x="8" y="38" width="136" height="52" rx="5" fill="url(#ut-tool)" />
      <rect x="8" y="38" width="136" height="52" rx="5" fill="none" stroke="#b7cbe4" strokeWidth="1.2" />

      <rect x="22" y="30" width="5" height="8" rx="2" fill="#2b405e" />
      <rect x="34" y="30" width="5" height="8" rx="2" fill="#2b405e" />
      <rect x="46" y="30" width="5" height="8" rx="2" fill="#2b405e" />
      <rect x="58" y="30" width="5" height="8" rx="2" fill="#2b405e" />
      <line x1="24" y1="34" x2="61" y2="34" stroke="#2b405e" strokeWidth="1.5" />

      <rect x="70" y="42" width="26" height="22" rx="3" fill="rgba(10,92,255,0.14)" stroke="rgba(10,92,255,0.45)" strokeWidth="1.2" />
      <text x="8" y="82" fontFamily="Arial, sans-serif" fontSize="10" fontWeight="700" fill="#0a5cff" letterSpacing="1.2">
        FLEETSQUAD
      </text>

      <path
        d="M150 42 L170 42 C176 42 179 45 179 50 L179 90 L150 90 Z"
        fill="url(#ut-body)"
      />
      <path
        d="M150 42 C158 42 164 44 170 49 L184 60 C189 64 191 69 192 74 L192 90 L150 90 Z"
        fill="url(#ut-body)"
      />
      <path
        d="M162 46 C168 46 172 49 176 55 L186 65 L158 65 Z"
        fill="url(#ut-glass)"
      />
      <path d="M150 66 L192 66 L192 72 L150 72 Z" fill="#56a8ff" opacity={0.4} />

      <path
        d="M192 72 C198 72 202 74 205 78 L208 82 C211 86 212 88 212 90 L185 90 Z"
        fill="url(#ut-body)"
      />

      <circle cx="186" cy="28" r="8" fill="#f59e0b" opacity="0.85" />
      <circle cx="186" cy="28" r="5" fill="#fde68a" opacity="0.9" />

      <path d="M200 68 L205 68 C207 71 206 74 202 75 L199 75 Z" fill="#fff" opacity={0.9} />
      <path d="M200 68 L205 68 C207 71 206 74 202 75 L199 75 Z" fill="#ffd98a" opacity={0.7} />

      <rect x="158" y="52" width="13" height="4" rx="2" fill="#0d2347" />
      <path d="M154 84 L162 84 M156 80 L164 80" stroke="#0a1d3d" strokeWidth="2.2" strokeLinecap="round" />

      <rect x="2" y="102" width="316" height="3" rx="1.5" fill="#0a1d3d" opacity="0.85" />

      <Wheel cx={52} cy={104} r={13.5} shadeId="ut-wheel-shade" />
      <Wheel cx={232} cy={104} r={13.5} shadeId="ut-wheel-shade" />
      <Wheel cx={286} cy={104} r={13.5} shadeId="ut-wheel-shade" />
    </svg>
  );
}
