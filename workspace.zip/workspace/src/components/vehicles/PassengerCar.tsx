import { Wheel, wheelDefs } from "./Wheels";

export default function PassengerCar() {
  return (
    <svg viewBox="0 0 240 104" role="img" aria-label="Passenger vehicle">
      <defs>
        <linearGradient id="car-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#274b85" />
          <stop offset="55%" stopColor="#16315e" />
          <stop offset="100%" stopColor="#0c2147" />
        </linearGradient>
        <linearGradient id="car-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7fb2e8" />
          <stop offset="45%" stopColor="#3f6fae" />
          <stop offset="100%" stopColor="#163a6e" />
        </linearGradient>
        <linearGradient id="car-trim" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#56a8ff" />
          <stop offset="100%" stopColor="#0a5cff" />
        </linearGradient>
        {wheelDefs("car-wheel-shade")}
      </defs>

      <path
        d="M12 58 C13 50 20 46 28 44 L40 43 C47 41 52 37 58 32 L116 22 C128 20 138 23 146 30 L176 45 C188 48 196 51 202 55 C214 59 228 63 233 69 L235 74 C236 78 233 81 228 81 L20 81 C11 81 9 76 10 69 Z"
        fill="url(#car-body)"
      />

      <path
        d="M58 32 L116 22 C128 20 138 23 146 30 L168 43 L108 44 L62 34 Z"
        fill="url(#car-glass)"
      />

      <path
        d="M170 47 C183 50 194 54 201 58 L200 64 L168 58 Z"
        fill="url(#car-glass)"
      />

      <path d="M22 78 C 60 86 180 86 218 78 L218 81 L22 81 Z" fill="url(#car-trim)" opacity={0.5} />

      <line x1="84" y1="52" x2="84" y2="76" stroke="#0a1d3d" strokeWidth="2" />
      <line x1="152" y1="58" x2="152" y2="77" stroke="#0a1d3d" strokeWidth="2" />

      <rect x="91" y="55" width="14" height="4" rx="2" fill="#1a3a6e" />
      <rect x="156" y="61" width="12" height="4" rx="2" fill="#1a3a6e" />

      <path d="M227 67 L231 67 C233 70 232 73 228 74 L224 74 Z" fill="#fff" opacity={0.9} />
      <path d="M227 67 L231 67 C233 70 232 73 228 74 L224 74 Z" fill="#ffd98a" opacity={0.75} />

      <path d="M12 60 L17 60 C19 64 18 67 14 68 L10 68 Z" fill="#ef4444" opacity={0.85} />

      <path
        d="M12 70 L22 70 M14 66 L24 66"
        stroke="#0a1d3d"
        strokeWidth="2.4"
        strokeLinecap="round"
      />

      <rect x="2" y="80" width="236" height="3" rx="1.5" fill="#0a1d3d" opacity="0.85" />

      <Wheel cx={58} cy={84} r={13} shadeId="car-wheel-shade" />
      <Wheel cx={188} cy={84} r={13} shadeId="car-wheel-shade" />
    </svg>
  );
}
