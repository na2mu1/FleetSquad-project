"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Wheel = Wheel;
exports.wheelDefs = wheelDefs;
const jsx_runtime_1 = require("react/jsx-runtime");
function Wheel({ cx, cy, r = 13, shadeId = "wheel-shade", }) {
    const rim = r * 0.62;
    return ((0, jsx_runtime_1.jsxs)("g", { children: [(0, jsx_runtime_1.jsx)("circle", { cx: cx, cy: cy, r: r, fill: "#0c1420" }), (0, jsx_runtime_1.jsx)("circle", { cx: cx, cy: cy, r: r, fill: "none", stroke: "#20324d", strokeWidth: 1.4 }), (0, jsx_runtime_1.jsx)("circle", { cx: cx, cy: cy, r: r - 1.6, fill: "none", stroke: "#2b405e", strokeWidth: 1 }), (0, jsx_runtime_1.jsx)("circle", { cx: cx, cy: cy, r: rim, fill: "none", stroke: "#5b6f8c", strokeWidth: 1.6 }), (0, jsx_runtime_1.jsx)("circle", { cx: cx, cy: cy, r: rim * 0.42, fill: "#7c8aa0" }), (0, jsx_runtime_1.jsx)("circle", { cx: cx, cy: cy, r: rim * 0.18, fill: "#c7d0dd" }), Array.from({ length: 6 }).map((_, i) => {
                const a = (i * Math.PI) / 3;
                return ((0, jsx_runtime_1.jsx)("line", { x1: cx + Math.cos(a) * rim * 0.4, y1: cy + Math.sin(a) * rim * 0.4, x2: cx + Math.cos(a) * rim, y2: cy + Math.sin(a) * rim, stroke: "#aebbc9", strokeWidth: 1.3, strokeLinecap: "round" }, i));
            }), (0, jsx_runtime_1.jsx)("circle", { cx: cx, cy: cy, r: r * 0.98, fill: `url(#${shadeId})`, opacity: 0.35 })] }));
}
function wheelDefs(id = "wheel-shade") {
    return ((0, jsx_runtime_1.jsxs)("radialGradient", { id: id, cx: "0.5", cy: "0.3", r: "0.9", children: [(0, jsx_runtime_1.jsx)("stop", { offset: "0%", stopColor: "#ffffff" }), (0, jsx_runtime_1.jsx)("stop", { offset: "60%", stopColor: "transparent" })] }));
}
