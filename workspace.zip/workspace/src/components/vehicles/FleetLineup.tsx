"use client";

import { motion } from "framer-motion";
import SemiTruck from "./SemiTruck";
import BoxTruck from "./BoxTruck";
import CargoVan from "./CargoVan";
import Pickup from "./Pickup";
import PassengerCar from "./PassengerCar";

const float = (delay: number) => ({
  animate: {
    y: [0, -7, 0],
  },
  transition: {
    duration: 5,
    repeat: Infinity,
    ease: "easeInOut" as const,
    delay,
  },
});

export default function FleetLineup() {
  return (
    <div className="relative mx-auto w-full max-w-6xl px-2">
      <div className="relative flex items-end justify-between gap-2 md:gap-4">
        <motion.div className="w-[30%] max-w-[430px]" {...float(0)}>
          <SemiTruck />
          <Shadow />
        </motion.div>
        <motion.div className="hidden w-[22%] max-w-[320px] sm:block" {...float(1.1)}>
          <BoxTruck />
          <Shadow />
        </motion.div>
        <motion.div className="hidden w-[18%] max-w-[280px] md:block" {...float(2.2)}>
          <CargoVan />
          <Shadow />
        </motion.div>
        <motion.div className="hidden w-[17%] max-w-[280px] lg:block" {...float(3.3)}>
          <Pickup />
          <Shadow />
        </motion.div>
        <motion.div className="w-[22%] max-w-[240px]" {...float(4.1)}>
          <PassengerCar />
          <Shadow />
        </motion.div>
      </div>

      <div className="mt-3 flex items-center gap-3 px-4 md:mt-4">
        <span className="h-2 w-16 rounded-full bg-sky/50 md:w-24" />
        <span className="h-2 flex-1 rounded-full bg-white/10" />
        <span className="h-2 w-10 rounded-full bg-sky/30 md:w-16" />
      </div>
    </div>
  );
}

function Shadow() {
  return (
    <div
      aria-hidden="true"
      className="mx-auto mt-[-6px] h-3 w-[85%] rounded-[50%] bg-black/30 blur-[6px]"
    />
  );
}
