import { Wheel, wheelDefs } from "./Wheels";

export default function SemiTruck() {
  return (
    <svg viewBox="0 0 430 154" role="img" aria-label="Semi truck">
      <defs>
        <linearGradient id="st-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2f5496" />
          <stop offset="55%" stopColor="#193762" />
          <stop offset="100%" stopColor="#0e2449" />
        </linearGradient>
        <linearGradient id="st-trailer" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f2f7fe" />
          <stop offset="100%" stopColor="#d5e3f6" />
        </linearGradient>
        <linearGradient id="st-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#8cc0f2" />
          <stop offset="100%" stopColor="#1a3f78" />
        </linearGradient>
        {wheelDefs("st-wheel-shade")}
      </defs>

      <rect x="6" y="34" width="244" height="78" rx="6" fill="url(#st-trailer)" />
      <rect x="6" y="34" width="244" height="78" rx="6" fill="none" stroke="#b7cbe4" strokeWidth="1" />

      <line x1="24" y1="38" x2="24" y2="108" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="60" y1="38" x2="60" y2="108" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="96" y1="38" x2="96" y2="108" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="132" y1="38" x2="132" y2="108" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="168" y1="38" x2="168" y2="108" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="204" y1="38" x2="204" y2="108" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="18" y1="58" x2="240" y2="58" stroke="#c7d8ec" strokeWidth="1.5" />
      <line x1="18" y1="86" x2="240" y2="86" stroke="#c7d8ec" strokeWidth="1.5" />

      <path
        d="M208 40 L232 40 L232 108 L208 108 Z"
        fill="rgba(10,92,255,0.1)"
        stroke="rgba(10,92,255,0.35)"
        strokeWidth="1.5"
      />
      <rect x="212" y="46" width="16" height="14" rx="2" fill="rgba(10,92,255,0.25)" />

      <rect x="222" y="76" width="8" height="16" rx="2" fill="rgba(239,68,68,0.6)" />

      <text x="10" y="94" fontFamily="Arial, sans-serif" fontSize="12" fontWeight="700" fill="#0a5cff" letterSpacing="2">
        FLEETSQUAD
      </text>
      <text x="10" y="106" fontFamily="Arial, sans-serif" fontSize="7" letterSpacing="1.4" fill="#7d8ba1">
        NATIONWIDE MOBILE SERVICE
      </text>

      <g>
        <rect x="216" y="112" width="7" height="8" fill="#20324d" />
        <rect x="228" y="112" width="7" height="8" fill="#20324d" />
        <rect x="213" y="118" width="25" height="4" rx="2" fill="#2b405e" />
        <rect x="216" y="120" width="7" height="4" fill="#0c1420" />
        <rect x="228" y="120" width="7" height="4" fill="#0c1420" />
      </g>

      <rect x="260" y="96" width="20" height="10" rx="2" fill="#123056" />
      <rect x="286" y="88" width="42" height="15" rx="6" fill="#0e2449" stroke="#274b85" strokeWidth="1" />

      <path d="M282 30 L286 30 L286 66 L282 66 Z" fill="#193762" />
      <path d="M284 26 L288 26 L288 32 L284 32 Z" fill="#123056" />
      <circle cx="286" cy="70" r="3" fill="#ef4444" />

      <path
        d="M258 110 L258 52 L318 50 Q324 50 324 54 L324 74 Q326 78 330 78 L398 74 Q412 72 420 82 L420 110 Z"
        fill="url(#st-body)"
      />

      <path d="M320 52 L342 52 L334 74 L322 74 Z" fill="url(#st-glass)" />

      <path d="M318 88 L420 88 L420 94 L318 94 Z" fill="#56a8ff" opacity={0.4} />

      <path d="M396 76 L420 76 Q424 78 424 82 L424 86 L396 86 Z" fill="#123056" />
      <rect x="400" y="78" width="18" height="6" rx="3" fill="#0a1d3d" />
      <line x1="403" y1="80" x2="403" y2="84" stroke="#274b85" strokeWidth="1" />
      <line x1="408" y1="80" x2="408" y2="84" stroke="#274b85" strokeWidth="1" />
      <line x1="413" y1="80" x2="413" y2="84" stroke="#274b85" strokeWidth="1" />

      <rect x="414" y="92" width="8" height="18" rx="3" fill="#0a1d3d" />
      <path d="M414 92 L422 92 L422 96 L414 96 Z" fill="#56a8ff" />

      <rect x="300" y="54" width="30" height="4" rx="2" fill="#0d2347" />
      <path d="M300 62 L318 62 M302 66 L320 66" stroke="#0a1d3d" strokeWidth="2.2" strokeLinecap="round" />

      <rect x="258" y="64" width="24" height="18" rx="3" fill="url(#st-glass)" opacity={0.85} />
      <rect x="306" y="60" width="12" height="12" rx="2" fill="#123056" />
      <line x1="312" y1="60" x2="306" y2="72" stroke="#274b85" strokeWidth="1.5" />

      <rect x="250" y="98" width="8" height="12" rx="2" fill="#123056" />

      <rect x="2" y="126" width="426" height="3" rx="1.5" fill="#0a1d3d" opacity="0.85" />

      <Wheel cx={40} cy={128} r={14} shadeId="st-wheel-shade" />
      <Wheel cx={74} cy={128} r={14} shadeId="st-wheel-shade" />
      <Wheel cx={108} cy={128} r={14} shadeId="st-wheel-shade" />
      <Wheel cx={316} cy={126} r={14} shadeId="st-wheel-shade" />
      <Wheel cx={392} cy={126} r={13} shadeId="st-wheel-shade" />
    </svg>
  );
}
