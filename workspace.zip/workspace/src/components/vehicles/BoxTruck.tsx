import { Wheel, wheelDefs } from "./Wheels";

export default function BoxTruck() {
  return (
    <svg viewBox="0 0 320 134" role="img" aria-label="Box truck">
      <defs>
        <linearGradient id="bt-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2f5496" />
          <stop offset="55%" stopColor="#193762" />
          <stop offset="100%" stopColor="#0e2449" />
        </linearGradient>
        <linearGradient id="bt-box" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#eef4fd" />
          <stop offset="100%" stopColor="#d4e3f7" />
        </linearGradient>
        <linearGradient id="bt-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#8cc0f2" />
          <stop offset="100%" stopColor="#1a3f78" />
        </linearGradient>
        {wheelDefs("bt-wheel-shade")}
      </defs>

      <rect x="8" y="30" width="170" height="64" rx="6" fill="url(#bt-box)" />
      <rect x="8" y="30" width="170" height="64" rx="6" fill="none" stroke="#b9cce4" strokeWidth="1.5" />

      <line x1="40" y1="34" x2="40" y2="90" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="88" y1="34" x2="88" y2="90" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="136" y1="34" x2="136" y2="90" stroke="#c7d8ec" strokeWidth="2" />
      <line x1="20" y1="56" x2="166" y2="56" stroke="#c7d8ec" strokeWidth="1.5" />

      <rect x="70" y="48" width="46" height="22" rx="3" fill="rgba(10,92,255,0.12)" stroke="rgba(10,92,255,0.4)" strokeWidth="1.2" />

      <text x="10" y="80" fontFamily="Arial, sans-serif" fontSize="11" fontWeight="700" fill="#0a5cff" letterSpacing="1.5">
        FLEETSQUAD
      </text>

      <path
        d="M188 34 L208 34 C214 34 217 37 217 42 L217 94 L188 94 Z"
        fill="url(#bt-body)"
      />

      <path
        d="M188 34 C196 34 202 36 208 41 L222 52 C227 56 230 61 231 66 L231 94 L188 94 Z"
        fill="url(#bt-body)"
      />

      <path
        d="M200 38 C206 38 210 41 214 47 L224 57 L196 57 Z"
        fill="url(#bt-glass)"
      />

      <path d="M188 66 L231 66 L231 72 L188 72 Z" fill="#56a8ff" opacity={0.4} />

      <path
        d="M231 68 C238 68 244 70 248 74 L252 78 C255 82 256 88 256 94 L225 94 Z"
        fill="url(#bt-body)"
      />

      <path d="M243 72 L248 72 C250 75 249 78 245 79 L242 79 Z" fill="#fff" opacity={0.9} />
      <path d="M243 72 L248 72 C250 75 249 78 245 79 L242 79 Z" fill="#ffd98a" opacity={0.7} />

      <rect x="230" y="54" width="5" height="34" rx="2.5" fill="#123056" />
      <circle cx="232.5" cy="88" r="2" fill="#0a5cff" />

      <rect x="196" y="44" width="14" height="4.5" rx="2" fill="#0d2347" />

      <path d="M192 88 L200 88 M194 84 L202 84" stroke="#0a1d3d" strokeWidth="2.4" strokeLinecap="round" />

      <rect x="2" y="104" width="316" height="3" rx="1.5" fill="#0a1d3d" opacity="0.85" />

      <Wheel cx={48} cy={106} r={13.5} shadeId="bt-wheel-shade" />
      <Wheel cx={92} cy={106} r={13.5} shadeId="bt-wheel-shade" />
      <Wheel cx={238} cy={106} r={13.5} shadeId="bt-wheel-shade" />
      <Wheel cx={292} cy={106} r={13.5} shadeId="bt-wheel-shade" />
    </svg>
  );
}
