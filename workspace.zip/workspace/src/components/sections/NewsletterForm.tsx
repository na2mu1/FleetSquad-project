"use client";

import { useState } from "react";
import { ArrowRight, Check } from "lucide-react";

export default function NewsletterForm() {
  const [subscribed, setSubscribed] = useState(false);

  return (
    <form
      className="mt-4 flex flex-col gap-3 sm:flex-row"
      onSubmit={(e) => {
        e.preventDefault();
        setSubscribed(true);
      }}
    >
      <label htmlFor="newsletter-email" className="sr-only">
        Email address
      </label>
      <input
        id="newsletter-email"
        type="email"
        required
        placeholder="work email"
        className="h-12 flex-1 rounded-[14px] border border-white/15 bg-white/5 px-4 text-sm text-white placeholder:text-slate-500 focus:border-sky/50 focus:outline-none focus:ring-2 focus:ring-sky/30"
      />
      <button
        type="submit"
        disabled={subscribed}
        className="inline-flex h-12 items-center justify-center gap-2 rounded-[14px] bg-gradient-to-r from-primary to-sky px-6 text-sm font-semibold text-white transition-transform duration-300 hover:scale-[1.03] disabled:cursor-default disabled:opacity-90"
      >
        {subscribed ? (
          <>
            Subscribed
            <Check className="size-4" />
          </>
        ) : (
          <>
            Subscribe
            <ArrowRight className="size-4" />
          </>
        )}
      </button>
    </form>
  );
}
