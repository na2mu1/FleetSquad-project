"use client";
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = CoverageMap;
const jsx_runtime_1 = require("react/jsx-runtime");
const framer_motion_1 = require("framer-motion");
const grid = [
    ".######################.",
    ".###########.....#######",
    ".###########....########",
    ".###########...#########",
    ".############.##########",
    ".######################.",
    "..#####################.",
    "...####################.",
    "...###################..",
    ".....#################..",
    "......####.......####...",
    "........##.........##...",
    "........##.........##...",
];
const COLS = 24;
const ROWS = 13;
const W = 1000;
const H = 560;
const extraDots = [
    { x: 20, y: 40 },
    { x: 58, y: 40 },
    { x: 96, y: 52 },
    { x: 38, y: 78 },
    { x: 76, y: 78 },
    { x: 38, y: 500 },
    { x: 76, y: 512 },
    { x: 110, y: 500 },
];
const pins = [
    { city: "Seattle", state: "WA", col: 3, row: 1, label: true },
    { city: "San Francisco", state: "CA", col: 3, row: 7 },
    { city: "Los Angeles", state: "CA", col: 4, row: 8, label: true },
    { city: "Denver", state: "CO", col: 9, row: 6 },
    { city: "Dallas", state: "TX", col: 10, row: 9, label: true },
    { city: "Houston", state: "TX", col: 11, row: 10 },
    { city: "Minneapolis", state: "MN", col: 14, row: 3 },
    { city: "Chicago", state: "IL", col: 15, row: 5, label: true },
    { city: "Atlanta", state: "GA", col: 17, row: 9 },
    { city: "Miami", state: "FL", col: 20, row: 11 },
    { city: "New York", state: "NY", col: 21, row: 3, label: true },
    { city: "Boston", state: "MA", col: 22, row: 2 },
];
function CoverageMap() {
    const cw = W / COLS;
    const ch = H / ROWS;
    const dots = [];
    grid.forEach((rowStr, r) => {
        for (let c = 0; c < rowStr.length; c++) {
            if (rowStr[c] === "#")
                dots.push({ x: c * cw + cw / 2, y: r * ch + ch / 2 });
        }
    });
    return ((0, jsx_runtime_1.jsxs)("div", { className: "relative overflow-hidden rounded-3xl border border-slate-100 bg-gradient-to-b from-[#0a1d3d] to-[#071028] p-6 shadow-[0_40px_90px_-40px_rgba(7,28,61,0.7)] sm:p-8", children: [(0, jsx_runtime_1.jsxs)("div", { className: "mb-5 flex flex-wrap items-center justify-between gap-3", children: [(0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsx)("p", { className: "font-heading text-base font-bold text-white", children: "Nationwide coverage" }), (0, jsx_runtime_1.jsx)("p", { className: "text-xs text-slate-400", children: "3,400+ service zones \u00B7 all 50 states" })] }), (0, jsx_runtime_1.jsxs)("span", { className: "inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-[11px] font-bold text-emerald-400", children: [(0, jsx_runtime_1.jsx)("span", { className: "size-1.5 animate-pulse rounded-full bg-fleet-success" }), "OPERATIONAL NOW"] })] }), (0, jsx_runtime_1.jsxs)("svg", { viewBox: `0 0 ${W} ${H}`, className: "h-auto w-full", role: "img", "aria-label": "Map of United States showing FleetSquad nationwide coverage", children: [(0, jsx_runtime_1.jsxs)("defs", { children: [(0, jsx_runtime_1.jsxs)("radialGradient", { id: "map-glow", cx: "0.5", cy: "0.4", r: "0.7", children: [(0, jsx_runtime_1.jsx)("stop", { offset: "0%", stopColor: "#0a5cff", stopOpacity: "0.25" }), (0, jsx_runtime_1.jsx)("stop", { offset: "100%", stopColor: "#0a5cff", stopOpacity: "0" })] }), (0, jsx_runtime_1.jsxs)("linearGradient", { id: "pin-grad", x1: "0", y1: "0", x2: "1", y2: "1", children: [(0, jsx_runtime_1.jsx)("stop", { offset: "0%", stopColor: "#56a8ff" }), (0, jsx_runtime_1.jsx)("stop", { offset: "100%", stopColor: "#0a5cff" })] })] }), (0, jsx_runtime_1.jsx)("rect", { width: W, height: H, rx: "20", fill: "url(#map-glow)" }), dots.map((d, i) => ((0, jsx_runtime_1.jsx)(framer_motion_1.motion.circle, { cx: d.x, cy: d.y, r: "4.5", fill: "#56a8ff", opacity: "0.5", initial: { opacity: 0, scale: 0 }, whileInView: { opacity: 0.5, scale: 1 }, viewport: { once: true, margin: "-60px" }, transition: { delay: (i % 20) * 0.02, duration: 0.3 } }, i))), extraDots.map((d, i) => ((0, jsx_runtime_1.jsx)(framer_motion_1.motion.circle, { cx: d.x, cy: d.y, r: "4", fill: "#56a8ff", opacity: "0.4", initial: { opacity: 0 }, whileInView: { opacity: 0.4 }, viewport: { once: true }, transition: { delay: 0.5 } }, `e-${i}`))), pins.map((p, i) => {
                        const x = p.col * cw + cw / 2;
                        const y = p.row * ch + ch / 2;
                        return ((0, jsx_runtime_1.jsxs)("g", { children: [(0, jsx_runtime_1.jsxs)(framer_motion_1.motion.g, { initial: { opacity: 0, scale: 0 }, whileInView: { opacity: 1, scale: 1 }, viewport: { once: true, margin: "-60px" }, transition: { delay: 0.5 + i * 0.12, type: "spring", stiffness: 260, damping: 16 }, children: [(0, jsx_runtime_1.jsxs)("circle", { cx: x, cy: y, r: "11", fill: "rgba(10,92,255,0.25)", children: [(0, jsx_runtime_1.jsx)("animate", { attributeName: "r", values: "8;20;8", dur: "2.6s", begin: `${i * 0.3}s`, repeatCount: "indefinite" }), (0, jsx_runtime_1.jsx)("animate", { attributeName: "opacity", values: "0.6;0;0.6", dur: "2.6s", begin: `${i * 0.3}s`, repeatCount: "indefinite" })] }), (0, jsx_runtime_1.jsx)("circle", { cx: x, cy: y, r: "5.5", fill: "url(#pin-grad)", stroke: "#fff", strokeWidth: "1.6" })] }), p.label && ((0, jsx_runtime_1.jsxs)("g", { children: [(0, jsx_runtime_1.jsx)("rect", { x: x - 44, y: y - 34, width: "88", height: "22", rx: "11", fill: "rgba(7,28,61,0.9)", stroke: "rgba(86,168,255,0.4)" }), (0, jsx_runtime_1.jsx)("text", { x: x, y: y - 19, textAnchor: "middle", fontSize: "11", fontWeight: "700", fill: "#fff", fontFamily: "Plus Jakarta Sans, sans-serif", children: p.city })] }))] }, p.city));
                    })] }), (0, jsx_runtime_1.jsxs)("div", { className: "mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-[11px] font-medium text-slate-400", children: [(0, jsx_runtime_1.jsxs)("span", { className: "inline-flex items-center gap-2", children: [(0, jsx_runtime_1.jsx)("span", { className: "size-2 rounded-full bg-sky" }), " Service zone"] }), (0, jsx_runtime_1.jsxs)("span", { className: "inline-flex items-center gap-2", children: [(0, jsx_runtime_1.jsxs)("span", { className: "relative grid size-3 place-items-center", children: [(0, jsx_runtime_1.jsx)("span", { className: "absolute size-3 rounded-full bg-primary/30" }), (0, jsx_runtime_1.jsx)("span", { className: "size-1.5 rounded-full bg-gradient-to-br from-sky to-primary" })] }), "Major metro dispatch"] }), (0, jsx_runtime_1.jsxs)("span", { className: "inline-flex items-center gap-2", children: [(0, jsx_runtime_1.jsx)("span", { className: "size-2 rounded-sm bg-white/40" }), " Technicians on standby"] })] })] }));
}
