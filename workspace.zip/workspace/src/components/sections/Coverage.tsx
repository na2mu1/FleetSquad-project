"use client";

import { motion } from "framer-motion";
import { Globe2, Clock3, Truck, ShieldCheck } from "lucide-react";
import Container from "@/components/site/Container";
import SectionHeading from "@/components/site/SectionHeading";
import { fadeUp, staggerContainer, viewport } from "@/lib/motion";
import CoverageMap from "./CoverageMap";

const stats = [
  { icon: Globe2, value: "50", suffix: "", label: "States covered" },
  { icon: Truck, value: "3,400+", suffix: "", label: "Service zones" },
  { icon: Clock3, value: "2 hrs", suffix: "", label: "Avg. emergency response" },
  { icon: ShieldCheck, value: "98.4%", suffix: "", label: "On-time arrival" },
];

const zones = [
  "Dallas–Fort Worth",
  "Houston Metro",
  "Chicago & Midwest",
  "Atlanta & Southeast",
  "New York Tri-State",
  "Los Angeles & SoCal",
  "Phoenix & Southwest",
  "Miami & Florida",
];

export default function Coverage() {
  return (
    <section id="coverage" className="section-pad bg-[#f7faff]">
      <Container>
        <div className="grid items-center gap-14 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <SectionHeading
              eyebrow="Coverage"
              title="Wherever the mission takes you, we're already there"
              subtitle="Our nationwide technician network means the same certified, consistent service in every state — from major metros to remote routes."
            />

            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="grid grid-cols-2 gap-4"
            >
              {stats.map((s) => {
                const Icon = s.icon;
                return (
                  <motion.div
                    key={s.label}
                    variants={fadeUp}
                    className="flex items-center gap-3.5 rounded-2xl border border-slate-100 bg-white p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary/25 hover:shadow-[0_20px_44px_-26px_rgba(7,28,61,0.3)]"
                  >
                    <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                      <Icon className="size-5" />
                    </span>
                    <div>
                      <p className="font-heading text-xl font-extrabold text-fleet-navy">
                        {s.value}
                      </p>
                      <p className="text-[13px] text-slate-500">{s.label}</p>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>

            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mt-6 rounded-2xl border border-slate-100 bg-white p-6"
            >
              <p className="mb-3 text-sm font-bold text-fleet-navy">Major metro hubs</p>
              <div className="flex flex-wrap gap-2">
                {zones.map((z) => (
                  <span
                    key={z}
                    className="rounded-full border border-slate-200 bg-[#f7faff] px-3.5 py-1.5 text-[13px] font-medium text-slate-600 transition-colors hover:border-primary/40 hover:text-primary"
                  >
                    {z}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>

          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={viewport}
          >
            <CoverageMap />
          </motion.div>
        </div>
      </Container>
    </section>
  );
}
