"use client";

import { motion } from "framer-motion";
import {
  BadgeCheck,
  Globe2,
  Zap,
  FileText,
  Building2,
  ArrowRight,
} from "lucide-react";
import Container from "@/components/site/Container";
import { Button } from "@/components/ui/button";
import { staggerContainer, fadeUp, scaleIn, viewport } from "@/lib/motion";

const reasons = [
  {
    icon: Globe2,
    title: "Nationwide Coverage",
    desc: "Technicians in all 50 states and 3,400+ service zones — with a 2-hour average emergency response.",
  },
  {
    icon: Zap,
    title: "Fast Scheduling",
    desc: "Book a slot in under 60 seconds. Live availability syncs with your fleet's operational calendar.",
  },
  {
    icon: FileText,
    title: "Digital Reports",
    desc: "Every service ships with a photo-documented report, part receipts, and maintenance history.",
  },
  {
    icon: Building2,
    title: "Enterprise Support",
    desc: "Dedicated account teams, invoicing, API integrations, and fleet-wide analytics for operations of any size.",
  },
];

export default function WhyFleetSquad() {
  return (
    <section id="about" className="section-pad relative overflow-hidden bg-fleet-navy">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -right-40 top-0 size-[520px] rounded-full bg-primary/25 blur-[130px]" />
        <div className="absolute -left-32 bottom-0 size-[440px] rounded-full bg-sky/20 blur-[120px]" />
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage:
              "linear-gradient(rgba(86,168,255,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(86,168,255,0.07) 1px, transparent 1px)",
            backgroundSize: "56px 56px",
          }}
        />
      </div>

      <Container className="relative">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="grid items-stretch gap-6 lg:grid-cols-[1.05fr_1.4fr]"
        >
          <motion.div
            variants={fadeUp}
            className="flex flex-col justify-between rounded-3xl border border-sky/20 bg-gradient-to-br from-[#0a2a5c] to-[#0a3d8f] p-9 lg:p-10"
          >
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-sky/35 bg-sky/15 px-4 py-1.5 font-heading text-xs font-bold uppercase tracking-[0.14em] text-sky">
                <span className="size-1.5 rounded-full bg-current shadow-[0_0_0_4px_rgba(10,92,255,0.15)]" />
                Why FleetSquad
              </span>
              <h2 className="mt-5 font-heading text-3xl font-extrabold leading-[1.1] tracking-tight text-white md:text-4xl">
                Technicians you can trust.
                <br />
                <span className="text-gradient-white">
                  Standards you can prove.
                </span>
              </h2>
              <p className="mt-5 text-lg leading-relaxed text-slate-300/85">
                Every tech is background-checked, ASE Master certified, and
                continuously trained on the latest OEM procedures — so quality
                is consistent in every state we serve.
              </p>
            </div>

            <div className="mt-8 rounded-2xl border border-sky/25 bg-white/5 p-6 backdrop-blur-sm">
              <div className="flex items-center gap-4">
                <span className="grid size-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-primary to-sky shadow-[0_12px_30px_-8px_rgba(10,92,255,0.6)]">
                  <BadgeCheck className="size-7 text-white" />
                </span>
                <div>
                  <p className="font-heading text-2xl font-extrabold text-white">
                    2,400+ ASE Master Technicians
                  </p>
                  <p className="mt-0.5 text-sm text-slate-400">
                    Average experience: 12+ years
                  </p>
                </div>
              </div>
              <div className="mt-5 grid grid-cols-3 gap-4 border-t border-white/10 pt-5 text-center">
                <div>
                  <p className="font-heading text-2xl font-extrabold text-white">
                    98%
                  </p>
                  <p className="text-xs text-slate-400">Certified pass rate</p>
                </div>
                <div>
                  <p className="font-heading text-2xl font-extrabold text-white">
                    40+
                  </p>
                  <p className="text-xs text-slate-400">OEM certifications</p>
                </div>
                <div>
                  <p className="font-heading text-2xl font-extrabold text-white">
                    0
                  </p>
                  <p className="text-xs text-slate-400">Subcontracted work</p>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            {reasons.map((r) => {
              const Icon = r.icon;
              return (
                <motion.div
                  key={r.title}
                  variants={scaleIn}
                  className="group flex flex-col rounded-3xl border border-white/10 bg-white/5 p-7 backdrop-blur-sm transition-all duration-500 hover:-translate-y-1.5 hover:border-sky/40 hover:bg-white/10"
                >
                  <span className="grid size-12 place-items-center rounded-xl bg-sky/15 text-sky transition-transform duration-500 group-hover:scale-110">
                    <Icon className="size-6" />
                  </span>
                  <h3 className="mt-5 font-heading text-lg font-bold text-white">
                    {r.title}
                  </h3>
                  <p className="mt-2 flex-1 text-[15px] leading-relaxed text-slate-400">
                    {r.desc}
                  </p>
                </motion.div>
              );
            })}
            <motion.div
              variants={scaleIn}
              className="col-span-1 flex flex-col justify-center rounded-3xl bg-gradient-to-br from-primary to-sky p-7 sm:col-span-2"
            >
              <p className="font-heading text-2xl font-extrabold leading-snug text-white">
                See how FleetSquad can protect your fleet&apos;s uptime.
              </p>
              <div className="mt-5">
                <Button
                  render={<a href="#book" />}
                  nativeButton={false}
                  className="h-12 rounded-[14px] bg-white px-6 text-[15px] font-semibold text-fleet-navy shadow-[0_12px_30px_-10px_rgba(0,0,0,0.4)] transition-transform duration-300 hover:scale-[1.03]"
                >
                  Get a free fleet assessment
                  <ArrowRight className="size-4" />
                </Button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
