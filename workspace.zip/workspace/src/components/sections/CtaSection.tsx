"use client";

import { motion } from "framer-motion";
import { ArrowRight, CalendarCheck, PhoneCall, ShieldCheck, Clock3 } from "lucide-react";
import Container from "@/components/site/Container";
import { Button } from "@/components/ui/button";
import { fadeUp, staggerContainer, viewport } from "@/lib/motion";

export default function CtaSection() {
  return (
    <section id="book" className="section-pad relative overflow-hidden bg-[#f7faff]">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-40 top-20 size-[480px] rounded-full bg-primary/15 blur-[130px]" />
        <div className="absolute -right-40 bottom-0 size-[460px] rounded-full bg-sky/20 blur-[130px]" />
      </div>

      <Container>
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="relative overflow-hidden rounded-[40px] border border-sky/25 bg-gradient-to-br from-fleet-navy-950 via-fleet-navy-900 to-[#0b3f9e] px-8 py-16 text-center shadow-[0_60px_120px_-50px_rgba(7,28,61,0.8)] md:px-16 md:py-24"
        >
          <div
            className="pointer-events-none absolute inset-0 opacity-40"
            style={{
              backgroundImage:
                "linear-gradient(rgba(86,168,255,0.09) 1px, transparent 1px), linear-gradient(90deg, rgba(86,168,255,0.09) 1px, transparent 1px)",
              backgroundSize: "52px 52px",
              maskImage: "radial-gradient(ellipse 70% 70% at 50% 50%, black 20%, transparent 75%)",
              WebkitMaskImage:
                "radial-gradient(ellipse 70% 70% at 50% 50%, black 20%, transparent 75%)",
            }}
          />

          <motion.span
            variants={fadeUp}
            className="relative inline-flex items-center gap-2 rounded-full border border-sky/35 bg-sky/15 px-5 py-2 font-heading text-xs font-bold uppercase tracking-[0.14em] text-sky"
          >
            <span className="size-1.5 rounded-full bg-current shadow-[0_0_0_4px_rgba(10,92,255,0.2)]" />
            Get started
          </motion.span>

          <motion.h2
            variants={fadeUp}
            className="relative mx-auto mt-6 max-w-3xl font-heading text-4xl font-extrabold leading-[1.08] tracking-tight text-white md:text-6xl"
          >
            Ready to Modernize Your{" "}
            <span className="text-gradient-white">Fleet Maintenance?</span>
          </motion.h2>

          <motion.p
            variants={fadeUp}
            className="relative mx-auto mt-6 max-w-xl text-lg leading-relaxed text-slate-300/85"
          >
            Get a free fleet assessment and see exactly what on-site mobile
            maintenance could save your operation — in uptime, dollars, and
            peace of mind.
          </motion.p>

          <motion.div
            variants={fadeUp}
            className="relative mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row"
          >
            <Button
              render={<a href="#contact" />}
              nativeButton={false}
              className="h-14 w-full rounded-[14px] bg-gradient-to-r from-primary to-sky px-8 text-base font-semibold text-white shadow-[0_18px_48px_-14px_rgba(10,92,255,0.8)] transition-transform duration-300 hover:scale-[1.03] sm:w-auto"
            >
              Book Fleet Service
              <ArrowRight className="size-5" />
            </Button>
            <Button
              render={<a href="#contact" />}
              nativeButton={false}
              className="h-14 w-full rounded-[14px] border border-white/25 bg-white/5 px-8 text-base font-semibold text-white backdrop-blur-md transition-colors duration-300 hover:border-white/40 hover:bg-white/10 sm:w-auto"
            >
              <CalendarCheck className="size-5" />
              Schedule a Demo
            </Button>
          </motion.div>

          <motion.div
            variants={fadeUp}
            className="relative mt-12 flex flex-wrap items-center justify-center gap-x-10 gap-y-4 text-sm text-slate-400"
          >
            <span className="inline-flex items-center gap-2">
              <PhoneCall className="size-4 text-sky" /> 24/7 nationwide dispatch
            </span>
            <span className="inline-flex items-center gap-2">
              <ShieldCheck className="size-4 text-sky" /> Free fleet assessment
            </span>
            <span className="inline-flex items-center gap-2">
              <Clock3 className="size-4 text-sky" /> Average demo: 30 minutes
            </span>
          </motion.div>
        </motion.div>
      </Container>
    </section>
  );
}
