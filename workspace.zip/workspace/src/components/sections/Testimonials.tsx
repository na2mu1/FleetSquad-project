"use client";

import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import Container from "@/components/site/Container";
import SectionHeading from "@/components/site/SectionHeading";
import { staggerContainer, fadeUp, viewport } from "@/lib/motion";

const logos = [
  { name: "NORTHBRIDGE", color: "text-slate-400" },
  { name: "HAULCORE", color: "text-slate-400" },
  { name: "METROFLEET", color: "text-slate-400" },
  { name: "TRANSLINE", color: "text-slate-400" },
  { name: "COASTALLINK", color: "text-slate-400" },
  { name: "STATEFLEET", color: "text-slate-400" },
];

const testimonials = [
  {
    quote:
      "FleetSquad cut our maintenance downtime by 41% in the first year. Their techs show up on time, the digital reports are flawless, and our compliance audits have never been easier.",
    name: "Sarah Whitfield",
    role: "VP of Fleet Operations",
    company: "Northbridge Logistics",
    initials: "SW",
    tone: "from-primary to-sky",
    stat: "41% less downtime",
  },
  {
    quote:
      "We rolled FleetSquad out across 1,800 government vehicles in six weeks. DOT inspections are handled on-site, and every record is audit-ready. It changed how our team operates.",
    name: "Daniel Osei",
    role: "Director, Fleet & Facilities",
    company: "Metro State Government",
    initials: "DO",
    tone: "from-fleet-navy to-fleet-navy-900",
    stat: "6-week rollout",
  },
  {
    quote:
      "The 2-hour emergency response is real. When a unit broke down 200 miles from our yard, a FleetSquad tech was there before our driver even finished the paperwork.",
    name: "Mei-Lin Chen",
    role: "Chief Operating Officer",
    company: "Haulcore Industries",
    initials: "MC",
    tone: "from-violet-500 to-purple-700",
    stat: "2-hr avg response",
  },
];

export default function Testimonials() {
  return (
    <section className="section-pad bg-[#f7faff]">
      <Container>
        <SectionHeading
          center
          eyebrow="Customers"
          title="Trusted by fleets that can't afford downtime"
          subtitle="Enterprise logistics, government fleets, rental companies, and utilities run their maintenance on FleetSquad."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="mb-12 grid grid-cols-2 gap-x-8 gap-y-4 sm:grid-cols-3 lg:grid-cols-6"
        >
          {logos.map((l) => (
            <motion.span
              key={l.name}
              variants={fadeUp}
              className={`font-heading text-center text-base font-bold tracking-[0.08em] ${l.color} transition-colors hover:text-fleet-navy sm:text-lg`}
            >
              {l.name}
            </motion.span>
          ))}
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="grid grid-cols-1 gap-6 lg:grid-cols-3"
        >
          {testimonials.map((t) => (
            <motion.figure
              key={t.name}
              variants={fadeUp}
              className="group relative flex flex-col rounded-3xl border border-slate-100 bg-white p-8 transition-all duration-500 hover:-translate-y-2 hover:border-primary/25 hover:shadow-[0_32px_64px_-28px_rgba(7,28,61,0.28)]"
            >
              <Quote className="absolute right-7 top-7 size-10 text-primary/10" />
              <div className="flex gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <blockquote className="mt-5 flex-1 text-[15.5px] leading-relaxed text-slate-700">
                “{t.quote}”
              </blockquote>
              <div className="mt-7 flex items-center justify-between border-t border-slate-100 pt-6">
                <div className="flex items-center gap-3.5">
                  <span
                    className={`grid size-12 place-items-center rounded-2xl bg-gradient-to-br font-heading text-sm font-bold text-white ${t.tone}`}
                  >
                    {t.initials}
                  </span>
                  <div>
                    <p className="font-heading text-[15px] font-bold text-fleet-navy">
                      {t.name}
                    </p>
                    <p className="text-[13px] text-slate-500">{t.role}</p>
                    <p className="text-[13px] font-semibold text-primary">
                      {t.company}
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-5 rounded-xl bg-[#f7faff] px-4 py-3 text-center">
                <span className="font-heading text-sm font-bold text-fleet-success">
                  {t.stat}
                </span>
              </div>
            </motion.figure>
          ))}
        </motion.div>
      </Container>
    </section>
  );
}
