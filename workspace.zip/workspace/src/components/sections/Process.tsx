"use client";

import { motion } from "framer-motion";
import { CalendarClock, UserCheck, Wrench, FileText, Flag } from "lucide-react";
import Container from "@/components/site/Container";
import SectionHeading from "@/components/site/SectionHeading";
import { fadeUp, staggerContainer, viewport } from "@/lib/motion";

const steps = [
  {
    icon: CalendarClock,
    step: "Step 01",
    title: "Request Service",
    desc: "Book on-site service in under 60 seconds from the portal, app, or a single call to 24/7 dispatch.",
  },
  {
    icon: UserCheck,
    step: "Step 02",
    title: "Technician Assigned",
    desc: "The nearest certified ASE Master Technician with the right parts and tools is assigned instantly.",
  },
  {
    icon: Wrench,
    step: "Step 03",
    title: "On-Site Repair",
    desc: "The tech arrives at your location — yard, depot, or roadside — and completes the work on schedule.",
  },
  {
    icon: FileText,
    step: "Step 04",
    title: "Digital Report",
    desc: "Photo-documented results, parts receipts, and recommendations land in your maintenance history automatically.",
  },
  {
    icon: Flag,
    step: "Step 05",
    title: "Fleet Back on Road",
    desc: "Your vehicle returns to service with verified readiness and a full record — mission continues.",
  },
];

export default function Process() {
  return (
    <section className="section-pad bg-white">
      <Container>
        <SectionHeading
          center
          eyebrow="How it works"
          title="From request to mission-ready in five steps"
          subtitle="A streamlined workflow designed around your operations — minimal friction, maximum uptime."
        />

        <div className="relative">
          <div className="absolute left-0 right-0 top-[34px] hidden h-0.5 bg-gradient-to-r from-primary/60 via-sky/40 to-primary/60 lg:block" />

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={viewport}
            className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-5 lg:gap-6"
          >
            {steps.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.step} variants={fadeUp} className="relative">
                  <div className="flex items-center gap-4 lg:flex-col lg:gap-0 lg:text-center">
                    <div className="relative z-10">
                      <div className="grid size-[68px] place-items-center rounded-2xl bg-gradient-to-br from-primary to-sky text-white shadow-[0_14px_32px_-10px_rgba(10,92,255,0.6)] transition-transform duration-500 hover:-translate-y-1">
                        <Icon className="size-7" />
                      </div>
                    </div>
                    <div className="lg:mt-6">
                      <span className="font-heading text-xs font-bold uppercase tracking-[0.12em] text-primary">
                        {s.step}
                      </span>
                      <h3 className="mt-1 font-heading text-lg font-bold text-fleet-navy">
                        {s.title}
                      </h3>
                    </div>
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-slate-500 lg:text-center">
                    {s.desc}
                  </p>
                  <span
                    aria-hidden="true"
                    className="absolute -bottom-5 right-1/2 hidden font-heading text-5xl font-extrabold text-slate-100 lg:block"
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </Container>
    </section>
  );
}
