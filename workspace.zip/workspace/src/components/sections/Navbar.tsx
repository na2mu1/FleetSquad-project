"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import Container from "@/components/site/Container";
import Logo from "@/components/site/Logo";

const links = [
  { label: "Home", href: "#top" },
  { label: "Services", href: "#services" },
  { label: "Industries", href: "#industries" },
  { label: "Coverage", href: "#coverage" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-x-0 top-0 z-50"
    >
      <div
        className={cn(
          "transition-all duration-500",
          scrolled
            ? "border-b border-white/40 bg-white/70 shadow-[0_12px_40px_-20px_rgba(7,28,61,0.25)] backdrop-blur-2xl"
            : "bg-transparent"
        )}
      >
        <Container>
          <div className="flex h-20 items-center justify-between gap-8">
            <Logo />

            <nav
              className="hidden items-center gap-8 lg:flex"
              aria-label="Primary"
            >
              {links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  className="relative text-[15px] font-medium text-slate-600 transition-colors hover:text-fleet-navy after:absolute after:-bottom-1.5 after:left-0 after:h-0.5 after:w-0 after:rounded-full after:bg-gradient-to-r after:from-primary after:to-sky after:transition-all after:duration-300 hover:after:w-full"
                >
                  {l.label}
                </a>
              ))}
            </nav>

            <div className="hidden items-center gap-3 lg:flex">
              <a
                href="#contact"
                className="px-2 text-[15px] font-semibold text-fleet-navy transition-colors hover:text-primary"
              >
                Sign in
              </a>
              <Button
                render={<a href="#book" />}
                nativeButton={false}
                className="h-11 rounded-[14px] bg-gradient-to-r from-primary to-sky px-6 text-[15px] font-semibold shadow-[0_12px_32px_-10px_rgba(10,92,255,0.55)] transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_18px_40px_-12px_rgba(10,92,255,0.6)]"
              >
                Book Fleet Service
                <ArrowRight className="size-4" />
              </Button>
            </div>

            <button
              onClick={() => setOpen(!open)}
              className="grid h-11 w-11 place-items-center rounded-xl border border-white/40 bg-white/60 text-fleet-navy backdrop-blur-md lg:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </Container>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden border-t border-white/40 bg-white/80 backdrop-blur-2xl lg:hidden"
            >
              <Container>
                <nav className="flex flex-col py-4" aria-label="Mobile">
                  {links.map((l) => (
                    <a
                      key={l.href}
                      href={l.href}
                      onClick={() => setOpen(false)}
                      className="border-b border-slate-100 py-4 text-[17px] font-medium text-fleet-navy transition-colors hover:text-primary"
                    >
                      {l.label}
                    </a>
                  ))}
                  <a
                    href="#contact"
                    onClick={() => setOpen(false)}
                    className="py-4 text-[17px] font-semibold text-fleet-navy hover:text-primary"
                  >
                    Sign in
                  </a>
                  <Button
                    render={<a href="#book" onClick={() => setOpen(false)} />}
                    nativeButton={false}
                    className="my-4 h-12 rounded-[14px] bg-gradient-to-r from-primary to-sky text-[15px] font-semibold"
                  >
                    Book Fleet Service
                    <ArrowRight className="size-4" />
                  </Button>
                </nav>
              </Container>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
}
