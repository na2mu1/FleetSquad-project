"use client";

import Container from "@/components/site/Container";
import SectionHeading from "@/components/site/SectionHeading";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "How far in advance do I need to book service?",
    a: "For scheduled preventive maintenance, most fleets book 3–7 days ahead, though same-week slots are usually available. Emergency roadside service is dispatched 24/7/365 with a 2-hour average response time.",
  },
  {
    q: "Are your technicians ASE certified?",
    a: "Yes. Every FleetSquad technician is ASE Master certified, background-checked, and continuously trained on OEM procedures. We never subcontract work — the technician you see is a FleetSquad employee.",
  },
  {
    q: "Do you service all vehicle types and all 50 states?",
    a: "We service Class 1–8 vehicles — semi trucks, box trucks, cargo vans, pickups, passenger vehicles, and specialized utility fleets — in all 50 states across 3,400+ service zones.",
  },
  {
    q: "What happens if a technician is late?",
    a: "Our 98.4% on-time rate is backed by a service guarantee. If a technician arrives outside the agreed window, that visit's labor fee is waived automatically — no forms, no phone calls.",
  },
  {
    q: "What do you charge and how does invoicing work?",
    a: "Pricing is flat-rate, transparent, and quoted upfront with zero surprises. Enterprise accounts receive consolidated monthly invoicing, PO support, and negotiated volume rates.",
  },
  {
    q: "Can FleetSquad integrate with our existing fleet management system?",
    a: "Yes. Our open API and direct integrations connect with major TMS, telematics, and fleet management platforms, so work orders and maintenance records flow into your stack automatically.",
  },
  {
    q: "Do you provide digital documentation for compliance?",
    a: "Every visit produces a photo-documented digital report with parts receipts, labor details, and recommendations — stored permanently and exportable for DOT and audit requirements.",
  },
];

export default function Faq() {
  return (
    <section className="section-pad bg-white">
      <Container className="max-w-3xl">
        <SectionHeading
          center
          eyebrow="FAQ"
          title="Answers, before you even ask"
          subtitle="Everything fleet managers ask us most — if you don't see your question, talk to a fleet expert."
        />

        <Accordion defaultValue={[faqs[0].q]}>
          {faqs.map((f) => (
            <AccordionItem
              key={f.q}
              value={f.q}
              className="mb-3 overflow-hidden rounded-2xl border border-slate-100 bg-[#f7faff] transition-colors duration-300 data-open:border-primary/30 data-open:bg-white data-open:shadow-[0_18px_44px_-26px_rgba(7,28,61,0.3)]"
            >
              <AccordionTrigger className="px-6 py-5 font-heading text-base font-bold text-fleet-navy hover:no-underline data-open:text-primary sm:text-[17px]">
                {f.q}
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-6 text-[15px] leading-relaxed text-slate-500">
                {f.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </Container>
    </section>
  );
}
