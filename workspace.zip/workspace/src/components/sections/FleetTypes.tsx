"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Container from "@/components/site/Container";
import SectionHeading from "@/components/site/SectionHeading";
import { staggerContainer, fadeUp, viewport } from "@/lib/motion";
import SemiTruck from "@/components/vehicles/SemiTruck";
import BoxTruck from "@/components/vehicles/BoxTruck";
import CargoVan from "@/components/vehicles/CargoVan";
import Pickup from "@/components/vehicles/Pickup";
import PassengerCar from "@/components/vehicles/PassengerCar";
import UtilityTruck from "@/components/vehicles/UtilityTruck";

const types = [
  {
    label: "Semi Trucks",
    desc: "Class 8 tractors and trailers — PMI, brakes, DOT, and over-the-road support.",
    tags: ["Class 8", "Long-haul", "DOT annual"],
    Vehicle: SemiTruck,
  },
  {
    label: "Box Trucks",
    desc: "Medium-duty straight trucks for delivery, moving, and distribution fleets.",
    tags: ["Medium duty", "Delivery", "Refrigeration"],
    Vehicle: BoxTruck,
  },
  {
    label: "Cargo Vans",
    desc: "High-roof cargo vans with suspension, brake, and electrical expertise.",
    tags: ["Class 1-3", "Last mile", "High roof"],
    Vehicle: CargoVan,
  },
  {
    label: "Pickups",
    desc: "Light-duty trucks for field service, construction, and utility crews.",
    tags: ["Light duty", "4x4", "Towing"],
    Vehicle: Pickup,
  },
  {
    label: "Passenger Vehicles",
    desc: "Sedans and SUVs for corporate fleets, rentals, and employee pools.",
    tags: ["Sedans", "SUVs", "Corporate"],
    Vehicle: PassengerCar,
  },
  {
    label: "Utility Fleets",
    desc: "Bucket, service, and municipal vehicles with specialized equipment care.",
    tags: ["Municipal", "Bucket trucks", "Specialized"],
    Vehicle: UtilityTruck,
  },
];

export default function FleetTypes() {
  return (
    <section id="industries" className="section-pad bg-white">
      <Container>
        <SectionHeading
          center
          eyebrow="Fleet Types"
          title="Built for every vehicle in your fleet"
          subtitle="From Class 8 linehaul to light-duty field trucks, our technicians are certified for the vehicles you depend on."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {types.map((t) => {
            const { Vehicle } = t;
            return (
              <motion.article
                key={t.label}
                variants={fadeUp}
                className="group overflow-hidden rounded-3xl border border-slate-100 bg-[#f7faff] transition-all duration-500 hover:-translate-y-2 hover:border-primary/25 hover:bg-white hover:shadow-[0_32px_64px_-28px_rgba(7,28,61,0.25)]"
              >
                <div className="flex h-40 items-end justify-center overflow-hidden bg-gradient-to-b from-[#eaf2fd] to-[#f7faff] px-6 transition-colors duration-500 group-hover:from-[#dbe9fb]">
                  <div className="w-[92%] transition-transform duration-700 group-hover:scale-105">
                    <Vehicle />
                  </div>
                </div>
                <div className="p-7">
                  <h3 className="font-heading text-xl font-bold text-fleet-navy">
                    {t.label}
                  </h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-slate-500">
                    {t.desc}
                  </p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {t.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-semibold text-slate-500"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <a
                    href="#book"
                    className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-primary transition-all duration-300 hover:gap-3"
                  >
                    Service this fleet
                    <ArrowRight className="size-4" />
                  </a>
                </div>
              </motion.article>
            );
          })}
        </motion.div>
      </Container>
    </section>
  );
}
