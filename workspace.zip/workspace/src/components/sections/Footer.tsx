import { Phone, Mail, MapPin } from "lucide-react";
import Container from "@/components/site/Container";
import Logo from "@/components/site/Logo";
import NewsletterForm from "./NewsletterForm";

const columns = [
  {
    title: "Services",
    links: ["Preventive Maintenance", "Fleet Repairs", "Mobile Diagnostics", "Emergency Roadside", "DOT Inspections", "Oil Changes", "Brake Service"],
  },
  {
    title: "Fleet Types",
    links: ["Semi Trucks", "Box Trucks", "Cargo Vans", "Pickups", "Passenger Vehicles", "Utility Fleets"],
  },
  {
    title: "Company",
    links: ["About us", "Our technicians", "Coverage map", "Careers", "Newsroom", "Contact"],
  },
  {
    title: "Support",
    links: ["Book service", "Fleet dashboard", "Help center", "API documentation", "System status", "Billing"],
  },
];

const socials = [
  {
    label: "LinkedIn",
    path: "M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.36V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45z",
  },
  {
    label: "X",
    path: "M18.24 2.25h3.31l-7.23 8.26 8.5 11.24h-6.66l-5.21-6.82-5.97 6.82H2.67l7.73-8.84L2.25 2.25h6.83l4.71 6.23 5.45-6.23z",
  },
  {
    label: "YouTube",
    path: "M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81zM9.55 15.57V8.43L15.82 12l-6.27 3.57z",
  },
];

export default function Footer() {
  return (
    <footer id="contact" className="bg-fleet-navy-950 text-slate-400">
      <Container className="py-16 md:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.15fr_2fr]">
          <div>
            <Logo light />
            <p className="mt-5 max-w-sm text-[15px] leading-relaxed">
              The nationwide on-site fleet maintenance company. ASE Master
              Technicians come to you — mission ready, everywhere.
            </p>

            <div className="mt-7 space-y-3 text-sm">
              <a
                href="tel:+18005551234"
                className="flex items-center gap-3 transition-colors hover:text-white"
              >
                <span className="grid size-9 place-items-center rounded-xl bg-white/5 text-sky">
                  <Phone className="size-4" />
                </span>
                1-800-FLEETSQ (1-800-353-3877)
              </a>
              <a
                href="mailto:dispatch@fleetsquad.io"
                className="flex items-center gap-3 transition-colors hover:text-white"
              >
                <span className="grid size-9 place-items-center rounded-xl bg-white/5 text-sky">
                  <Mail className="size-4" />
                </span>
                dispatch@fleetsquad.io
              </a>
              <div className="flex items-center gap-3">
                <span className="grid size-9 place-items-center rounded-xl bg-white/5 text-sky">
                  <MapPin className="size-4" />
                </span>
                Nationwide · HQ in Dallas, TX
              </div>
            </div>

            <div className="mt-7 flex gap-3">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href="#contact"
                  aria-label={s.label}
                  className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-300 transition-all duration-300 hover:-translate-y-1 hover:border-sky/40 hover:bg-gradient-to-br hover:from-primary hover:to-sky hover:text-white"
                >
                  <svg
                    width="17"
                    height="17"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    aria-hidden="true"
                  >
                    <path d={s.path} />
                  </svg>
                </a>
              ))}
            </div>
          </div>

          <div>
            <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
              {columns.map((col) => (
                <div key={col.title}>
                  <h4 className="font-heading text-sm font-bold uppercase tracking-wider text-white">
                    {col.title}
                  </h4>
                  <ul className="mt-5 space-y-3">
                    {col.links.map((l) => (
                      <li key={l}>
                        <a
                          href="#contact"
                          className="text-sm transition-colors hover:text-sky"
                        >
                          {l}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="mt-12 rounded-2xl border border-white/10 bg-white/5 p-6">
              <p className="font-heading text-base font-bold text-white">
                Get fleet maintenance insights monthly
              </p>
              <p className="mt-1 text-sm text-slate-400">
                Cost benchmarks, compliance updates, and uptime tips. No spam.
              </p>
              <NewsletterForm />
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-5 border-t border-white/10 pt-8 md:flex-row">
          <p className="text-[13px]">
            © {new Date().getFullYear()} FleetSquad, Inc. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-7 gap-y-2 text-[13px]">
            <a href="#contact" className="transition-colors hover:text-white">
              Privacy Policy
            </a>
            <a href="#contact" className="transition-colors hover:text-white">
              Terms of Service
            </a>
            <a href="#contact" className="transition-colors hover:text-white">
              Cookie Settings
            </a>
            <a href="#contact" className="transition-colors hover:text-white">
              Accessibility
            </a>
          </div>
        </div>
      </Container>
    </footer>
  );
}
