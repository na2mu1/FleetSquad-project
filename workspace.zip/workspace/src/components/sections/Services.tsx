"use client";

import { motion } from "framer-motion";
import {
  Wrench,
  ShieldCheck,
  Activity,
  Siren,
  CalendarClock,
  ClipboardCheck,
  Droplets,
  Disc3,
  ArrowRight,
} from "lucide-react";
import Container from "@/components/site/Container";
import SectionHeading from "@/components/site/SectionHeading";
import { staggerContainer, fadeUp, viewport } from "@/lib/motion";

const services = [
  {
    icon: Wrench,
    title: "Preventive Maintenance",
    desc: "Scheduled PMIs that catch wear before it becomes a breakdown — extending vehicle life and protecting uptime.",
    tone: "bg-primary/10 text-primary",
  },
  {
    icon: Activity,
    title: "Fleet Repairs",
    desc: "ASE Master Technicians complete mechanical, electrical, and body repairs on-site, fast and fully documented.",
    tone: "bg-violet-500/10 text-violet-600",
  },
  {
    icon: Siren,
    title: "Mobile Diagnostics",
    desc: "Advanced scan tools and telematics arrive at your location to isolate faults without a shop visit.",
    tone: "bg-amber-500/10 text-amber-600",
  },
  {
    icon: CalendarClock,
    title: "Emergency Roadside",
    desc: "24/7/365 dispatch with a 2-hour average response for breakdowns, jump starts, and tire changes anywhere.",
    tone: "bg-red-500/10 text-red-600",
  },
  {
    icon: ClipboardCheck,
    title: "Scheduled Maintenance",
    desc: "Recurring service plans aligned to OEM intervals, fleet schedules, and your busiest operational windows.",
    tone: "bg-emerald-500/10 text-emerald-600",
  },
  {
    icon: ShieldCheck,
    title: "DOT Inspections",
    desc: "Annual, periodic, and roadside DOT inspections completed by certified inspectors, audit-ready every time.",
    tone: "bg-sky-500/10 text-sky-600",
  },
  {
    icon: Droplets,
    title: "Oil Changes",
    desc: "Express oil and fluid service using OEM-spec products, with a digital record for every vehicle.",
    tone: "bg-cyan-500/10 text-cyan-600",
  },
  {
    icon: Disc3,
    title: "Brake Service",
    desc: "Pads, rotors, drums, air brakes, and ABS — inspected and replaced to stop confidently on every route.",
    tone: "bg-fuchsia-500/10 text-fuchsia-600",
  },
];

export default function Services() {
  return (
    <section id="services" className="section-pad bg-[#f7faff]">
      <Container>
        <SectionHeading
          eyebrow="Services"
          title="Every service your fleet needs. At your location."
          subtitle="One partner, one digital record, and ASE Master Technicians who come to you — wherever your vehicles are."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4"
        >
          {services.map((s) => {
            const Icon = s.icon;
            return (
              <motion.article
                key={s.title}
                variants={fadeUp}
                className="group relative flex flex-col overflow-hidden rounded-3xl border border-slate-100 bg-white p-7 transition-all duration-500 hover:-translate-y-2 hover:border-primary/25 hover:shadow-[0_28px_60px_-26px_rgba(7,28,61,0.25)]"
              >
                <div className="absolute inset-x-0 top-0 h-[3px] origin-left scale-x-0 bg-gradient-to-r from-primary to-sky transition-transform duration-500 group-hover:scale-x-100" />
                <span
                  className={`grid size-14 place-items-center rounded-2xl transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6 ${s.tone}`}
                >
                  <Icon className="size-6" />
                </span>
                <h3 className="mt-6 font-heading text-xl font-bold text-fleet-navy">
                  {s.title}
                </h3>
                <p className="mt-2.5 flex-1 text-[15px] leading-relaxed text-slate-500">
                  {s.desc}
                </p>
                <a
                  href="#book"
                  className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-primary transition-all duration-300 hover:gap-3"
                >
                  Book this service
                  <ArrowRight className="size-4" />
                </a>
              </motion.article>
            );
          })}
        </motion.div>
      </Container>
    </section>
  );
}
