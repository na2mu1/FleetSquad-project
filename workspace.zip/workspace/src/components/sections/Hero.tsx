"use client";

import { useEffect, useRef } from "react";
import {
  motion,
  useInView,
  useMotionValue,
  useSpring,
} from "framer-motion";
import {
  ArrowRight,
  PhoneCall,
  ShieldCheck,
  MapPin,
  Clock3,
  Star,
} from "lucide-react";
import Container from "@/components/site/Container";
import { Button } from "@/components/ui/button";
import FleetLineup from "@/components/vehicles/FleetLineup";

function Counter({
  to,
  decimals = 0,
  suffix = "",
}: {
  to: number;
  decimals?: number;
  suffix?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const mv = useMotionValue(0);
  const spring = useSpring(mv, { duration: 1.8, bounce: 0 });

  useEffect(() => {
    if (inView) mv.set(to);
  }, [inView, to, mv]);

  useEffect(() => {
    const unsub = spring.on("change", (v) => {
      if (ref.current) {
        ref.current.textContent =
          v.toLocaleString("en-US", {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
          }) + suffix;
      }
    });
    return unsub;
  }, [spring, decimals, suffix]);

  return <span ref={ref}>0</span>;
}

const stats = [
  { label: "Service visits completed", value: 1.2, decimals: 1, suffix: "M+" },
  { label: "Fleet vehicles supported", value: 38, decimals: 0, suffix: "K+" },
  { label: "On-time arrival rate", value: 98.4, decimals: 1, suffix: "%" },
  { label: "Customer satisfaction", value: 4.9, decimals: 1, suffix: "/5" },
];

const badges = [
  { icon: ShieldCheck, label: "ASE Master Certified" },
  { icon: MapPin, label: "50-State Coverage" },
  { icon: Clock3, label: "24/7 Dispatch" },
  { icon: Star, label: "4.9/5 Rated" },
];

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1, delayChildren: 0.2 } },
};

const item = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-screen flex-col overflow-hidden bg-gradient-to-b from-fleet-navy-950 via-fleet-navy-900 to-[#0b3f9e]"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-40 -top-40 size-[560px] rounded-full bg-primary/40 blur-[120px]" />
        <div className="absolute -right-32 top-1/4 size-[480px] rounded-full bg-sky/30 blur-[120px]" />
        <div className="absolute -bottom-48 left-1/3 size-[520px] rounded-full bg-primary/25 blur-[130px]" />
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "linear-gradient(rgba(86,168,255,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(86,168,255,0.08) 1px, transparent 1px)",
            backgroundSize: "64px 64px",
            maskImage:
              "radial-gradient(ellipse 80% 60% at 50% 0%, black 20%, transparent 75%)",
            WebkitMaskImage:
              "radial-gradient(ellipse 80% 60% at 50% 0%, black 20%, transparent 75%)",
          }}
        />
        <Sparkles />
      </div>

      <Container className="relative z-10 flex flex-1 flex-col justify-center pb-10 pt-32 md:pt-36">
        <motion.div
          variants={stagger}
          initial="hidden"
          animate="visible"
          className="mx-auto max-w-4xl text-center"
        >
          <motion.div variants={item} className="flex justify-center">
            <span className="inline-flex items-center gap-2.5 rounded-full border border-sky/30 bg-white/5 px-5 py-2 text-sm font-medium text-sky backdrop-blur-md">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-fleet-success opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-fleet-success" />
              </span>
              Nationwide mobile fleet maintenance · 50 states covered
            </span>
          </motion.div>

          <motion.h1
            variants={item}
            className="mt-7 font-heading text-[2.75rem] font-extrabold leading-[1.04] tracking-tight text-white sm:text-6xl lg:text-[4.5rem]"
          >
            Keep Every Fleet
            <br />
            <span className="text-gradient-white">Mission Ready.</span>
          </motion.h1>

          <motion.p
            variants={item}
            className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-slate-300/90 sm:text-xl"
          >
            ASE Master Technicians come to your location for preventive
            maintenance, diagnostics, repairs, inspections, and emergency
            roadside service nationwide.
          </motion.p>

          <motion.div
            variants={item}
            className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row"
          >
            <Button
              render={<a href="#book" />}
              nativeButton={false}
              className="h-14 w-full rounded-[14px] bg-gradient-to-r from-primary to-sky px-8 text-base font-semibold shadow-[0_16px_44px_-12px_rgba(10,92,255,0.7)] transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_22px_56px_-14px_rgba(10,92,255,0.85)] sm:w-auto"
            >
              Book Fleet Service
              <ArrowRight className="size-5" />
            </Button>
            <Button
              render={<a href="#contact" />}
              nativeButton={false}
              className="h-14 w-full rounded-[14px] border border-white/25 bg-white/5 px-8 text-base font-semibold text-white backdrop-blur-md transition-all duration-300 hover:border-white/40 hover:bg-white/10 sm:w-auto"
            >
              <PhoneCall className="size-5" />
              Talk to Fleet Expert
            </Button>
          </motion.div>

          <motion.div
            variants={item}
            className="mt-10 flex flex-wrap items-center justify-center gap-x-7 gap-y-3"
          >
            {badges.map((b) => {
              const Icon = b.icon;
              return (
                <span
                  key={b.label}
                  className="inline-flex items-center gap-2 text-sm font-medium text-slate-300/90"
                >
                  <Icon className="size-4 text-sky" />
                  {b.label}
                </span>
              );
            })}
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mt-12 grid w-full max-w-5xl grid-cols-2 gap-4 lg:grid-cols-4"
        >
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-2xl border border-white/15 bg-white/5 px-6 py-6 text-center backdrop-blur-xl transition-colors duration-300 hover:border-sky/40 hover:bg-white/10"
            >
              <div className="font-heading text-3xl font-extrabold tracking-tight text-white md:text-[2.35rem]">
                <Counter
                  to={s.value}
                  decimals={s.decimals}
                  suffix={s.suffix}
                />
              </div>
              <div className="mt-1.5 text-sm text-slate-400">{s.label}</div>
            </div>
          ))}
        </motion.div>
      </Container>

      <motion.div
        initial={{ opacity: 0, y: 60 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 1, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 pb-10"
      >
        <FleetLineup />
      </motion.div>

      <div className="pointer-events-none absolute bottom-0 left-0 right-0 z-0 h-40 bg-gradient-to-t from-fleet-navy-950/80 to-transparent" />
    </section>
  );
}

function Sparkles() {
  const dots = [
    { top: "18%", left: "12%", d: 0 },
    { top: "28%", left: "88%", d: 1.2 },
    { top: "55%", left: "8%", d: 2.1 },
    { top: "64%", left: "92%", d: 0.6 },
    { top: "38%", left: "24%", d: 1.8 },
    { top: "22%", left: "60%", d: 2.6 },
  ];
  return (
    <>
      {dots.map((p, i) => (
        <motion.span
          key={i}
          className="absolute size-1.5 rounded-full bg-sky/70"
          style={{ top: p.top, left: p.left }}
          animate={{ opacity: [0.1, 0.9, 0.1], scale: [0.8, 1.3, 0.8] }}
          transition={{ duration: 3.2, repeat: Infinity, delay: p.d }}
        />
      ))}
    </>
  );
}
