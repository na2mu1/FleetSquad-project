"use client";

import { motion } from "framer-motion";
import { MapPin, Wrench, Truck, CalendarDays, FileBarChart, Gauge } from "lucide-react";
import Container from "@/components/site/Container";
import SectionHeading from "@/components/site/SectionHeading";
import { fadeUp, staggerContainer, viewport } from "@/lib/motion";

const vehicles = [
  { unit: "TRK-1184", status: "On-site service", tone: "bg-fleet-success", pct: 72 },
  { unit: "TRK-2037", status: "Scheduled PM", tone: "bg-fleet-warning", pct: 48 },
  { unit: "VAN-0882", status: "Available", tone: "bg-fleet-success", pct: 100 },
  { unit: "TRK-6604", status: "In diagnostics", tone: "bg-sky", pct: 33 },
  { unit: "SUV-4412", status: "Available", tone: "bg-fleet-success", pct: 100 },
];

const orders = [
  { id: "WO-4821", task: "Brake pads · rear axle", eta: "45 min", tone: "text-sky bg-sky/10" },
  { id: "WO-4820", task: "Transmission service", eta: "2 hrs", tone: "text-amber-600 bg-amber-500/10" },
  { id: "WO-4819", task: "DOT annual inspection", eta: "Done", tone: "text-emerald-600 bg-emerald-500/10" },
];

const techs = [
  { name: "A. Rivera", zone: "Dallas, TX", busy: true },
  { name: "D. Chen", zone: "Phoenix, AZ", busy: true },
  { name: "S. Okafor", zone: "Atlanta, GA", busy: false },
  { name: "M. Vazquez", zone: "Miami, FL", busy: false },
];

const reports = [
  { name: "Maintenance cost · Q3", type: "PDF · 2.4 MB", tone: "bg-red-500" },
  { name: "Fleet health summary", type: "PDF · 1.1 MB", tone: "bg-sky" },
  { name: "DOT compliance log", type: "CSV · 860 KB", tone: "bg-emerald-500" },
];

const cal = [
  { d: 8, m: "Tue" },
  { d: 9, m: "Wed" },
  { d: 10, m: "Thu" },
  { d: 11, m: "Fri" },
  { d: 12, m: "Sat" },
];

const bars = [46, 62, 40, 78, 58, 90, 70, 96];

export default function Dashboard() {
  return (
    <section className="section-pad overflow-hidden bg-white">
      <Container>
        <SectionHeading
          center
          eyebrow="Fleet command center"
          title="The entire fleet on one screen"
          subtitle="Live vehicle status, schedules, work orders, and technician tracking — a real-time command center for every operation."
        />

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="relative mx-auto max-w-5xl"
        >
          <div className="absolute -inset-x-8 -top-10 -z-10 h-72 bg-gradient-to-r from-primary/10 via-sky/15 to-primary/10 blur-3xl" />

          <div className="rounded-[26px] bg-gradient-to-b from-[#1c2b45] to-[#0c1424] p-2.5 shadow-[0_60px_120px_-40px_rgba(7,28,61,0.55)] sm:p-3.5">
            <div className="rounded-[20px] bg-white p-4 sm:p-5">
              <div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <span className="grid size-7 place-items-center rounded-lg bg-gradient-to-br from-primary to-sky">
                    <Truck className="size-4 text-white" />
                  </span>
                  <span className="text-[13px] font-bold text-fleet-navy">
                    FleetSquad · Operations
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10px] font-bold text-emerald-600">
                    <span className="size-1.5 animate-pulse rounded-full bg-fleet-success" />
                    LIVE
                  </span>
                  <span className="grid size-7 place-items-center rounded-full bg-gradient-to-br from-fleet-navy to-fleet-navy-900 text-[9px] font-bold text-white">
                    FO
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-12">
                <div className="space-y-4 md:col-span-7">
                  <Panel title="Vehicle Status" icon={Gauge} count="2,847 online">
                    <div className="space-y-2">
                      {vehicles.map((v) => (
                        <div key={v.unit} className="flex items-center gap-2.5">
                          <span className={`size-2 rounded-full ${v.tone}`} />
                          <span className="w-20 shrink-0 text-[11px] font-semibold text-fleet-navy">
                            {v.unit}
                          </span>
                          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100">
                            <motion.div
                              className="h-full rounded-full bg-gradient-to-r from-primary to-sky"
                              initial={{ width: 0 }}
                              whileInView={{ width: `${v.pct}%` }}
                              viewport={{ once: true }}
                              transition={{ delay: 0.3, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                            />
                          </div>
                          <span className="w-28 shrink-0 text-right text-[10px] text-slate-400">
                            {v.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </Panel>

                  <Panel title="Analytics · Cost per mile" icon={FileBarChart} count="▼ 6.8%">
                    <div className="flex h-24 items-end gap-2">
                      {bars.map((h, i) => (
                        <motion.div
                          key={i}
                          className="flex-1 rounded-t-md bg-gradient-to-t from-primary to-sky"
                          initial={{ height: 0 }}
                          whileInView={{ height: `${h}%` }}
                          viewport={{ once: true }}
                          transition={{ delay: 0.2 + i * 0.05, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                        />
                      ))}
                    </div>
                  </Panel>

                  <Panel title="Maintenance Calendar" icon={CalendarDays} count="14 upcoming">
                    <div className="grid grid-cols-5 gap-2">
                      {cal.map((c) => (
                        <div
                          key={c.d}
                          className="rounded-lg border border-slate-100 bg-slate-50 py-2 text-center transition-colors hover:border-primary/40 hover:bg-primary/5"
                        >
                          <p className="text-[9px] font-semibold uppercase text-slate-400">
                            {c.m}
                          </p>
                          <p className="text-sm font-bold text-fleet-navy">{c.d}</p>
                        </div>
                      ))}
                    </div>
                  </Panel>
                </div>

                <div className="space-y-4 md:col-span-5">
                  <Panel title="Active Work Orders" icon={Wrench} count="23">
                    <div className="space-y-2">
                      {orders.map((o) => (
                        <div
                          key={o.id}
                          className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2"
                        >
                          <div className="min-w-0">
                            <p className="text-[11px] font-bold text-fleet-navy">{o.id}</p>
                            <p className="truncate text-[10px] text-slate-400">{o.task}</p>
                          </div>
                          <span className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-bold ${o.tone}`}>
                            {o.eta}
                          </span>
                        </div>
                      ))}
                    </div>
                  </Panel>

                  <Panel title="Technician Tracking" icon={MapPin} count="Live map">
                    <div className="space-y-2">
                      {techs.map((t) => (
                        <div key={t.name} className="flex items-center gap-2.5">
                          <span className="grid size-7 place-items-center rounded-full bg-gradient-to-br from-sky to-primary text-[9px] font-bold text-white">
                            {t.name.split(" ").map((n) => n[0]).join("")}
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="text-[11px] font-semibold text-fleet-navy">{t.name}</p>
                            <p className="text-[9px] text-slate-400">{t.zone}</p>
                          </div>
                          <span
                            className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-bold ${
                              t.busy ? "bg-sky/10 text-sky" : "bg-emerald-500/10 text-emerald-600"
                            }`}
                          >
                            <span className={`size-1 rounded-full ${t.busy ? "bg-sky" : "bg-fleet-success"}`} />
                            {t.busy ? "On job" : "Free"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </Panel>

                  <Panel title="Reports" icon={FileBarChart} count="3 new">
                    <div className="space-y-2">
                      {reports.map((r) => (
                        <div key={r.name} className="flex items-center gap-2.5">
                          <span className={`size-2.5 rounded-sm ${r.tone}`} />
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[11px] font-semibold text-fleet-navy">
                              {r.name}
                            </p>
                          </div>
                          <span className="text-[9px] text-slate-400">{r.type}</span>
                        </div>
                      ))}
                    </div>
                  </Panel>
                </div>
              </div>
            </div>

            <div className="mx-auto mt-1 h-1.5 w-1/4 rounded-full bg-[#223351]" />
          </div>

          <div className="mx-auto mt-0 h-3 w-[82%] rounded-b-2xl bg-gradient-to-b from-[#223351] to-[#0c1424] shadow-[0_30px_60px_-30px_rgba(7,28,61,0.6)]" />
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="mx-auto mt-16 grid max-w-5xl grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6"
        >
          {["Vehicle Status", "Maintenance Calendar", "Active Work Orders", "Technician Tracking", "Analytics", "Reports"].map(
            (f, i) => (
              <motion.div
                key={f}
                variants={fadeUp}
                className="rounded-2xl border border-slate-100 bg-[#f7faff] px-4 py-5 text-center transition-all duration-300 hover:-translate-y-1 hover:border-primary/25 hover:bg-white hover:shadow-[0_18px_40px_-24px_rgba(7,28,61,0.25)]"
              >
                <span className="font-heading text-2xl font-extrabold text-primary">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <p className="mt-1 text-[13px] font-semibold text-fleet-navy">{f}</p>
              </motion.div>
            )
          )}
        </motion.div>
      </Container>
    </section>
  );
}

function Panel({
  title,
  icon: Icon,
  count,
  children,
}: {
  title: string;
  icon: React.ElementType;
  count: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_10px_30px_-20px_rgba(7,28,61,0.2)]">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="size-3.5 text-primary" />
          <span className="text-[11.5px] font-bold text-fleet-navy">{title}</span>
        </div>
        <span className="text-[10px] font-semibold text-slate-400">{count}</span>
      </div>
      {children}
    </div>
  );
}
