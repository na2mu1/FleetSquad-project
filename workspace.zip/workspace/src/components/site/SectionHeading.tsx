"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { fadeUp, staggerContainer, viewport } from "@/lib/motion";

export default function SectionHeading({
  eyebrow,
  title,
  subtitle,
  center = false,
  dark = false,
  className,
}: {
  eyebrow?: string;
  title: React.ReactNode;
  subtitle?: string;
  center?: boolean;
  dark?: boolean;
  className?: string;
}) {
  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      whileInView="visible"
      viewport={viewport}
      className={cn(
        "mb-14 max-w-3xl md:mb-16",
        center && "mx-auto text-center",
        className
      )}
    >
      {eyebrow && (
        <motion.span
          variants={fadeUp}
          className={cn(
            "inline-flex items-center gap-2 rounded-full border px-4 py-1.5 font-heading text-xs font-bold uppercase tracking-[0.14em]",
            dark
              ? "border-sky/35 bg-sky/15 text-sky"
              : "border-primary/20 bg-primary/10 text-primary"
          )}
        >
          <span className="size-1.5 rounded-full bg-current shadow-[0_0_0_4px_rgba(10,92,255,0.15)]" />
          {eyebrow}
        </motion.span>
      )}
      <motion.h2
        variants={fadeUp}
        className={cn(
          "mt-5 font-heading text-4xl font-extrabold leading-[1.08] tracking-tight md:text-5xl",
          dark ? "text-white" : "text-fleet-navy"
        )}
      >
        {title}
      </motion.h2>
      {subtitle && (
        <motion.p
          variants={fadeUp}
          className={cn(
            "mt-5 text-lg leading-relaxed",
            dark ? "text-slate-300/85" : "text-slate-500"
          )}
        >
          {subtitle}
        </motion.p>
      )}
    </motion.div>
  );
}
