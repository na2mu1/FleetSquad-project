import Link from "next/link";
import { cn } from "@/lib/utils";

export default function Logo({
  className,
  light = false,
}: {
  className?: string;
  light?: boolean;
}) {
  return (
    <Link
      href="#top"
      className={cn("group inline-flex items-center gap-2.5", className)}
      aria-label="FleetSquad home"
    >
      <span className="relative grid h-10 w-10 place-items-center rounded-[14px] bg-gradient-to-br from-primary to-sky shadow-[0_10px_24px_-8px_rgba(10,92,255,0.6)] transition-transform duration-300 group-hover:scale-105">
        <svg width="22" height="22" viewBox="0 0 64 64" fill="none" aria-hidden="true">
          <path
            d="M16 44V20l8 8 8-16 8 16 8-8v24"
            fill="none"
            stroke="#fff"
            strokeWidth="5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span
        className={cn(
          "font-heading text-xl font-extrabold tracking-tight transition-colors",
          light ? "text-white" : "text-fleet-navy"
        )}
      >
        FleetSquad
      </span>
    </Link>
  );
}
