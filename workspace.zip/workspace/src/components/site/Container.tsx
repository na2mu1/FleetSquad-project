import Link from "next/link";
import { cn } from "@/lib/utils";

export default function Container({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mx-auto w-full max-w-[1400px] px-6 md:px-10 lg:px-12", className)}>
      {children}
    </div>
  );
}

export { Link };
